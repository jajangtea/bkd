<?php
class AmChartTypes extends CEnumerable
{
	const AmPieChart = "AmPieChart";  
	const AmRadarChart = "AmRadarChart";
	const AmSerialChart = "AmSerialChart";
	const AmXYChart = "AmXYChart";
} 

?>